import type {Request, Response, NextFunction} from 'express';
import {Types} from 'mongoose';
import LikeCollection from '../like/collection';

/**
 * Checks if a like with likeId is req.params exists
 */
const isLikeExists = async (req: Request, res: Response, next: NextFunction) => {
  const validFormat = Types.ObjectId.isValid(req.params.likeId);
  const like = validFormat ? await LikeCollection.findOne(req.params.likeId) : '';
  if (!like) {
    res.status(404).json({
      error: {
        likeNotFound: `Like with like ID ${req.params.likeId} does not exist.`
      }
    });
    return;
  }
  next();
};

/**
 * Checks if the user has already liked the post
 */
 const notAlreadyLiked = async (req: Request, res: Response, next: NextFunction) => {
    const likes = await LikeCollection.findLikesForFreet(req.body.id);
    for (const like of likes) {
        if (like.authorId._id.toString() === req.session.userId) {
            res.status(404).json({
                error: {
                    alreadyLiked: `You have already liked that freet.`
                }
                });
            return;
        }
    }
    next();
};

export {
  isLikeExists,
  notAlreadyLiked
};

