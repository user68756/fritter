import type {NextFunction, Request, Response} from 'express';
import express from 'express';
import LikeCollection from './collection';
import * as userValidator from '../user/middleware';
import * as freetValidator from '../freet/middleware';
import * as likeValidator from '../like/middleware'
import * as util from './util';

const router = express.Router();

/**
 * Get likes on a given freet
 *
 * @name GET /api/likes
 *
 * @return {LikeResponse[]} - An array of likes associated with freet with freedId id
 * @throws {400} - If freedId is not given
 *
 */
router.get(
'/',
async (req: Request, res: Response, next: NextFunction) => {
    // Check if freetId query parameter was supplied
    if (req.query.freetId !== undefined) {
    next();
    return;
    }
    res.status(400).json("Freet not given.");
},
async (req: Request, res: Response) => {
    const likes = await LikeCollection.findLikesForFreet(req.query.freetId as string);
    const response = likes.map(util.constructLikeResponse);
    res.status(200).json(response);
}
);

/** 
 * Create a new like. 
 * 
 * @name POST /api/likes
 * 
 * @return {LikeResponse} - The created like 
 * @throws {403} - If the user is not logged in 
 * @throws {404} - If no freet has given freedId 
 * */

router.post('/', [userValidator.isUserLoggedIn, likeValidator.notAlreadyLiked], async (req: Request, res: Response) => {
    const userId = (req.session.userId as string) ?? ''; // Will not be an empty string since its validated in isUserLoggedIn    
    const freetId = req.body.id as string ?? ''; // will not be an empty string since its validated in isFreetExists    
    const like = await LikeCollection.addOne(userId, freetId);
    res.status(201).json({message: 'You have liked this freet.', like: util.constructLikeResponse(like)});
    }
);

/**
 * Remove a like from a post
 *
 * @name DELETE /api/likes/:id
 *
 * @return {string} - A success message
 * @throws {403} - If the user is not logged in 
 * @throws {404} - If the likeId is not valid
 */
 router.delete(
    '/:likeId?',
    [
      userValidator.isUserLoggedIn,
      likeValidator.isLikeExists
    ],
    async (req: Request, res: Response) => {
      await LikeCollection.deleteOne(req.params.likeId);
      res.status(200).json({
        message: 'Your like was removed successfully.'
      });
    }
  );
  
export {router as likeRouter};