import type {HydratedDocument, Types} from 'mongoose';
import type {Like} from './model';
import LikeModel from './model';
import FreetCollection from '../freet/collection';

class LikeCollection {
/**
 * Add a freet to the collection
 *
 * @param {string} authorId - The id of the user liking the freet
 * @param {string} freetId - The id of the freet being liked
 * @return {Promise<HydratedDocument<Like>>} - The newly created freet
 */
static async addOne(authorId: Types.ObjectId | string, freetId: Types.ObjectId | string): Promise<HydratedDocument<Like>> {
    const date = new Date();
    const like = new LikeModel({
    authorId,
    freetId,
    dateCreated: date,
    });
    await like.save(); // Saves like to MongoDB
    return like.populate('authorId', 'freetId');
}

/**
 * Find like by likeId
 * 
 * @param {string} likeId The id of the like
 * @return {Promise<HydratedDocument<Like>> | Promise<null> }
 */
 static async findOne(likeId: string): Promise<Array<HydratedDocument<Like>>> {
    return LikeModel.find({_id: likeId}).sort({dateModified: -1}).populate('authorId', 'freetId');
   }

/**
 * Find all likes by freetId
 *
 * @param {string} freetId - The id of the freet 
 * @return {Promise<HydratedDocument<Like>[]> | Promise<null> } - The likes associated with the freet with the given freetId, if any
 */

 static async findLikesForFreet(freetId: string): Promise<Array<HydratedDocument<Like>>> {
    const freet = await FreetCollection.findOne(freetId);
    return LikeModel.find({freetId: (freet) ? freet._id : freetId}).sort({dateModified: -1}).populate('authorId');
 }

 /**
  * Remove a like with given likeId. 
  * 
  * @param {string} likeId - The likeId of like to remove
  * @return {Promise<Boolean>} - true if the freet has been deleted, false otherwise   
  */
  static async deleteOne(likeId: Types.ObjectId | string): Promise<boolean> {
    const like = await LikeModel.deleteOne({_id: likeId});
    return like !== null;
  }

  /**
   * Delete all the likes by the given author // might be wrong
   *
   * @param {string} authorId - The id of user whose freets are to be deleted
   */
   static async deleteMany(authorId: Types.ObjectId | string): Promise<void> {
    await LikeModel.deleteMany({authorId});
  }
}

export default LikeCollection;